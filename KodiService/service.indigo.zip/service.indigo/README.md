XBMC Indigo Service
===================

This service integrates XBMC/Kodi with IndigoDomotics system.
It sends events to Indigo about changing menu, player events, volume, etc.

Please, visit this page https://github.com/tenallero/Indigo-XBMC/wiki for documentation.